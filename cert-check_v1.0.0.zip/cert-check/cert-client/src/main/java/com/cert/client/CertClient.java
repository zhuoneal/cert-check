package com.cert.client;

import com.cert.common.SecretEncryption;
import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.util.CharsetUtil;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Properties;

/**
 * @author onealzhuyingjie
 * @date 20210919 11:14 PM
 **/
public class CertClient {
    private final String host;
    private final int port;
    private final String cert;

    private boolean isAvailable = false;

    public static SecretEncryption encryption = new SecretEncryption();


    public static void main(String[] args) throws Exception {
        CertClient certClient = new CertClient();
        certClient.start();
        System.out.println("是否有效："+ certClient.isAvailable());
    }

    public CertClient() {
        Properties properties = new Properties();
        try {
            properties.load(CertClient.class.getClassLoader().getResourceAsStream("resource.properties"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.host = properties.getProperty("host");
        this.port = Integer.valueOf(properties.getProperty("port"));
        this.cert = properties.getProperty("cert");
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void start() throws Exception {
        EventLoopGroup group = new NioEventLoopGroup();
        try {
            Bootstrap b = new Bootstrap();
            b.group(group)
                    .channel(NioSocketChannel.class)
                    .remoteAddress(new InetSocketAddress(host, port))
                    .handler(new ChannelInitializer<SocketChannel>() {

                        @Override
                        protected void initChannel(SocketChannel ch) throws Exception {
                            ch.pipeline().addLast(new CertHandler(cert));
                        }

                    });
            ChannelFuture f = b.connect().sync();
            f.channel().closeFuture().sync();
        } finally {
            group.shutdownGracefully().sync();
        }
    }

    private class CertHandler extends SimpleChannelInboundHandler<ByteBuf> {

        private String cert;

        CertHandler(String cert) {
            this.cert = cert;
        }

        @Override
        public void channelActive(ChannelHandlerContext ctx) throws Exception {
            ctx.writeAndFlush(Unpooled.copiedBuffer(cert, CharsetUtil.UTF_8));
        }

        @Override
        protected void channelRead0(ChannelHandlerContext ctx, ByteBuf in) throws Exception {
            String response = in.toString(CharsetUtil.UTF_8);
            String plain = encryption.decrypt(response);
            String replace = plain.replace(cert, "");
            isAvailable = Boolean.valueOf(replace);
            System.out.println("Client received: " + replace);
        }

        @Override
        public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
            cause.printStackTrace();
            ctx.close();
        }

    }
}
