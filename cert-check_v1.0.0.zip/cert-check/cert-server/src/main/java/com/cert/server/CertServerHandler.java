package com.cert.server;

import com.cert.common.SecretEncryption;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.util.CharsetUtil;
import io.netty.util.internal.StringUtil;

/**
 * @author onealzhuyingjie
 * @date 20210920 12:04 AM
 **/
@ChannelHandler.Sharable
public class CertServerHandler extends ChannelInboundHandlerAdapter {

    public static SecretEncryption encryption = new SecretEncryption();

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        ByteBuf in = (ByteBuf) msg;
        String cert = in.toString(CharsetUtil.UTF_8);
        System.out.println("Server received cert: " + cert);
        String plainResponse = cert + String.valueOf(checkCert(cert));
        ctx.write(Unpooled.copiedBuffer(encryption.encrypt(plainResponse), CharsetUtil.UTF_8));
    }

    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
        // 将未决消息冲刷到远程节点，并且关闭该Channel
        ctx.writeAndFlush(Unpooled.EMPTY_BUFFER)
                .addListener(ChannelFutureListener.CLOSE);
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        cause.printStackTrace();
        ctx.close();
    }

    public boolean checkCert(String cert) {
        String plain = encryption.decrypt(cert);
        if (StringUtil.isNullOrEmpty(plain)) {
            return false;
        }
        String expire = Config.get("cert." + plain + ".expire");
        if (StringUtil.isNullOrEmpty(expire)) {
            return false;
        }
        Long expireTime = Long.valueOf(expire);

        return System.currentTimeMillis() > expireTime;
    }

    public static void main(String[] args) {
        // 生成证书
        System.out.println(encryption.encrypt("UzEZm1wef4I9LqiukwsY"));
    }

}
