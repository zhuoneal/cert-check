package com.cert.server;

import java.io.IOException;
import java.util.Properties;

/**
 * @author onealzhuyingjie
 * @date 20210920 1:25 AM
 **/
public class Config {
    private static Properties properties = new Properties();

    static {
        try {
            properties.load(Config.class.getClassLoader().getResourceAsStream("resource.properties"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String get(String key) {
        return properties.getProperty(key);
    }

    public static Integer getInteger(String key) {
        return Integer.valueOf(get(key));
    }
}
