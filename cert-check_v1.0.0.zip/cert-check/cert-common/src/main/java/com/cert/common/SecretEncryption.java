package com.cert.common;

import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

/**
 * Created by  on 2018/5/2.
 */
public class SecretEncryption {
    private byte[] hideKeyByte;

    private SecretKey keySpec;

    private final static String salt = "superman";

    private final static String DEFAULT_CHARSET = "UTF-8";

    private final static String SECRET = "1234567890abcdef";

    public SecretEncryption() {
        try {
            this.hideKeyByte = SECRET.getBytes(DEFAULT_CHARSET);
            this.keySpec = new SecretKeySpec(hideKeyByte, "AES");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    public String encrypt(String secret) {
        if (secret == null || secret.length() == 0)
            return "";
        Cipher cipher = null;
        secret = secret + salt;
        try {
            cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, keySpec);
            return Base64.getEncoder().encodeToString((cipher.doFinal(secret.getBytes(DEFAULT_CHARSET))));
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | UnsupportedEncodingException | InvalidKeyException | IllegalBlockSizeException | BadPaddingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public String decrypt(String secretHidden) {
        if (secretHidden == null || secretHidden.length() == 0)
            return "";
        Cipher cipher = null;
        try {
            cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, keySpec);
            String plainSalt = new String(cipher.doFinal(Base64.getDecoder().decode(secretHidden)), DEFAULT_CHARSET);
            return plainSalt.substring(0, plainSalt.length() - salt.length());
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | UnsupportedEncodingException | BadPaddingException | IllegalBlockSizeException | InvalidKeyException e) {
            e.printStackTrace();
        }

        return null;
    }

    public static void main(String[] args) {
        SecretEncryption encryption = new SecretEncryption();
        String encrypt = encryption.encrypt("UzEZm1wef4I9LqiukwsY");
        System.out.println("证书是：" + encrypt);
        String decrypt = encryption.decrypt(encrypt);
        System.out.println("原文是：" + decrypt);
    }

}

